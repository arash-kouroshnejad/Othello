package Control;

public interface Logic {
    void handle(int x, int y);
}
