package Model;

public enum Result {
    Player1,
    Player2,
    Tie
}
